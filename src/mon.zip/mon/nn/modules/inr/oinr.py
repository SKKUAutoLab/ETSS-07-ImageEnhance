#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""O-INR.

This module implements O-INR, introduced in the paper: "Implicit Representations
via Operator Learning," Pal et al. (2024).

References:
    https://github.com/vsingh-group/oinr
"""

from __future__ import annotations

__all__ = [

]

import torch
from torch import nn

from mon.nn.modules import normalization as norm


# region O-INR Network

class OINR_2D(nn.Module):
 
	def __init__(self, in_channels: int = 40, out_channels: int = 3):
		super().__init__()
		self.in_channels  = in_channels
		self.out_channels = out_channels

		self.approx_conv1 = nn.Conv2d(in_channels,   64,   3, 1, padding="same", bias=False)
		self.approx_conv2 = nn.Conv2d(64,  128, 3, 1, padding="same", bias=False)
		self.approx_conv3 = nn.Conv2d(128, 128, 3, 1, padding="same", bias=False)
		self.approx_conv4 = nn.Conv2d(128, 64,  3, 1, padding="same", bias=False)
		self.approx_conv5 = nn.Conv2d(64,  out_channels,    3, 1, padding="same", bias=False)

	def forward(self, x: torch.Tensor, verbose: bool = False) -> torch.Tensor:
		x = self.approx_conv1(x)
		x = torch.sin(x)
		x = self.approx_conv2(x)
		x = torch.sin(x)
		x = self.approx_conv3(x)
		x = torch.sin(x)
		x = self.approx_conv4(x)
		x = torch.sin(x)
		x = self.approx_conv5(x)
		signal = x
		return signal

# endregion
