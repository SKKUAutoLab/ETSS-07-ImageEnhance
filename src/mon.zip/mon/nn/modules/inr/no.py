#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Neural Operator.

This module implements Neural Operator.

References:
    https://github.com/2y7c3/Super-Resolution-Neural-Operator
"""

from __future__ import annotations

__all__ = [

]

import torch


# region Neural Operator

def make_coords(
    shape  : list[int] | tuple[int, int],
    ranges : list[int] = None,
    flatten: bool      = True
) -> torch.Tensor:
    """Make coordinates at grid centers."""
    coord_seqs = []
    for i, n in enumerate(shape):
        if ranges is None:
            v0, v1 = -1, 1
        else:
            v0, v1 = ranges[i]
        r   = (v1 - v0) / (2 * n)
        seq = v0 + r + (2 * r) * torch.arange(n).float()
        coord_seqs.append(seq)
    # ret = torch.stack(torch.meshgrid(*coord_seqs), dim=-1)
    ret = torch.stack(torch.meshgrid(*coord_seqs, indexing="ij"), dim=-1)
    if flatten:
        ret = ret.view(-1, ret.shape[-1])
    return ret
 
# endregion
