#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Prior Package.

This package implements different type of priors.
"""

from __future__ import annotations

import mon.nn.modules.prior.image
from mon.nn.modules.prior.image import *
