#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""LNO.

This module implement our idea: Low-light Image Enhancement Neural Operator.
"""

from __future__ import annotations

__all__ = [
    "LNO",
]

from abc import ABC
from typing import Any, Literal

import torch
from fvcore.nn import parameter_count
from torch.nn import functional as F
from torch.nn.common_types import _size_2_t

from mon import core, nn
from mon.globals import MODELS, Scheme, Task
from mon.vision import filtering
from mon.vision.enhance import base, utils

console      = core.console
current_file = core.Path(__file__).absolute()
current_dir  = current_file.parents[0]
LDA          = nn.LayeredFeatureAggregation

bilateral_ksize = (3, 3)
bilateral_color = 0.1
bilateral_space = (1.5, 1.5)


# region Loss

class Loss(nn.Loss):
    
    def __init__(
        self,
        exp_mean    : float = 0.6,
        weight_spa  : float = 1,
        weight_exp  : float = 10,
        weight_color: float = 5,
        weight_tv   : float = 1600,
        reduction   : Literal["none", "mean", "sum"] = "mean",
        *args, **kwargs
    ):
        super().__init__(reduction=reduction, *args, **kwargs)
        self.weight_spa   = weight_spa
        self.weight_exp   = weight_exp
        self.weight_color = weight_color
        self.weight_tv    = weight_tv
        
        self.loss_spa     = nn.SpatialConsistencyLoss(8, reduction=reduction)
        self.loss_exp     = nn.ExposureControlLoss(16, exp_mean, reduction=reduction)
        self.loss_color   = nn.ColorConstancyLoss(reduction=reduction)
        self.loss_tv      = nn.TotalVariationLoss(reduction=reduction)
        
    def forward(
        self,
        image       : torch.Tensor,
        illumination: torch.Tensor,
        enhanced    : torch.Tensor,
    ) -> torch.Tensor:
        loss_spa   = self.loss_spa(input=enhanced, target=image)
        loss_exp   = self.loss_exp(input=enhanced)
        loss_color = self.loss_color(input=enhanced)
        loss_tv    = self.loss_tv(input=illumination)
        loss = (
              self.weight_spa   * loss_spa
            + self.weight_exp   * loss_exp
            + self.weight_color * loss_color
            + self.weight_tv    * loss_tv
        )
        return loss


class LossHSV(nn.Loss):
    
    def __init__(
        self,
        exp_mean    : float = 0.1,
        weight_spa  : float = 1,
        weight_tv   : float = 20,
        weight_exp  : float = 8,
        weight_spar : float = 5,
        weight_depth: float = 1,
        reduction: Literal["none", "mean", "sum"] = "mean",
        *args, **kwargs
    ):
        super().__init__(reduction=reduction, *args, **kwargs)
        self.weight_spa   = weight_spa
        self.weight_tv    = weight_tv
        self.weight_exp   = weight_exp
        self.weight_spar  = weight_spar
        self.weight_depth = weight_depth
        
        self.loss_exp   = nn.ExposureValueControlLoss(16, exp_mean, reduction=reduction)
        self.loss_tv    = nn.TotalVariationLoss(reduction=reduction)
        self.loss_color = nn.ColorConstancyLoss(reduction=reduction)
        
    def forward(
        self,
        image       : torch.Tensor,
        illumination: torch.Tensor,
        enhanced    : torch.Tensor,
    ) -> torch.Tensor:
        loss_spa   = torch.mean(torch.abs(torch.pow(illumination - image, 2)))
        loss_tv    = self.loss_tv(illumination)
        loss_exp   = torch.mean(self.loss_exp(illumination))
        loss_spar  = torch.mean(enhanced)
        loss_color = self.loss_color(enhanced)
        loss = (
              self.weight_spa   * loss_spa
            + self.weight_tv    * loss_tv
            + self.weight_exp   * loss_exp
            + self.weight_spar  * loss_spar
            + self.weight_color * loss_color
        )
        return loss

# endregion


# region Modules

def make_coords(
    shape  : list[int] | tuple[int, int],
    ranges : list[int] = None,
    flatten: bool      = True
) -> torch.Tensor:
    """Make coordinates at grid centers."""
    coord_seqs = []
    for i, n in enumerate(shape):
        if ranges is None:
            v0, v1 = -1, 1
        else:
            v0, v1 = ranges[i]
        r   = (v1 - v0) / (2 * n)
        seq = v0 + r + (2 * r) * torch.arange(n).float()
        coord_seqs.append(seq)
    # ret = torch.stack(torch.meshgrid(*coord_seqs), dim=-1)
    ret = torch.stack(torch.meshgrid(*coord_seqs, indexing="ij"), dim=-1)
    if flatten:
        ret = ret.view(-1, ret.shape[-1])
    return ret


class NO(nn.Module, ABC):
    
    def interpolate_image(self, image: torch.Tensor) -> torch.Tensor:
        """Reshapes the image based on new resolution."""
        return F.interpolate(image, size=(self.down_size, self.down_size), mode="bicubic")
    
    @staticmethod
    def filter_up(
        x_lr  : torch.Tensor,
        y_lr  : torch.Tensor,
        x_hr  : torch.Tensor,
        radius: int = 3
    ):
        """Applies the guided filter to upscale the predicted image. """
        gf   = filtering.FastGuidedFilter(radius=radius)
        y_hr = gf(x_lr, y_lr, x_hr)
        y_hr = torch.clip(y_hr, 0.0, 1.0)
        return y_hr
    
    @staticmethod
    def replace_v_component(image_hsv: torch.Tensor, v_new: torch.Tensor) -> torch.Tensor:
        """Replaces the `V` component of an HSV image `[1, 3, H, W]`."""
        image_hsv[:, -1, :, :] = v_new
        return image_hsv
    
    @staticmethod
    def replace_i_component(image_hvi: torch.Tensor, i_new: torch.Tensor) -> torch.Tensor:
        """Replaces the `I` component of an HVI image `[1, 3, H, W]`."""
        image_hvi[:, 2, :, :] = i_new
        return image_hvi


class NO_HSV(NO):
    
    def __init__(
        self,
        width      : int   = 256,
        blocks     : int   = 16,
        n_resblocks: int   = 16,
        n_feats    : int   = 64,
        res_scale  : float = 1,
        scale      : int   = 1,
        gf_radius  : int   = 3,
        use_denoise: bool  = False,
    ):
        super().__init__()
        self.width       = width
        self.gf_radius   = gf_radius
        self.use_denoise = use_denoise
        self.scale       = scale
        
        self.encoder = nn.EDSREncoder(
            in_channels = 1,
            n_resblocks = n_resblocks,
            n_feats     = n_feats,
            res_scale   = res_scale,
            scale       = scale,
        )
        self.conv00  = nn.Conv2d((64 + 2) * 4 + 2, self.width, 1)
        self.conv0   = nn.GalerkinSimpleAttention(self.width, blocks)
        self.conv1   = nn.GalerkinSimpleAttention(self.width, blocks)
        self.fc1     = nn.Conv2d(self.width,    256, 1)
        self.fc2     = nn.Conv2d(256, 1,  1)
        self.dba     = nn.BoundaryAwarePrior(eps=0.05, normalized=False)
        self.inp     = None
        self.feat    = None
    
    def query_rgb(
        self,
        image: torch.Tensor,
        feat : torch.Tensor,
        coord: torch.Tensor,
        cell : torch.Tensor
    ) -> torch.Tensor:
        feat   = (feat)
        pos_lr = make_coords(feat.shape[-2:], flatten=False).to(image.device) \
            .permute(2, 0, 1) \
            .unsqueeze(0).expand(feat.shape[0], 2, *feat.shape[-2:])
        
        rx         = 2 / feat.shape[-2] / 2
        ry         = 2 / feat.shape[-1] / 2
        vx_lst     = [-1, 1]
        vy_lst     = [-1, 1]
        eps_shift  = 1e-6
        
        rel_coords = []
        feat_s     = []
        areas      = []
        for vx in vx_lst:
            for vy in vy_lst:
                coord_ = coord.clone()
                coord_[:, :, :, 0] += vx * rx + eps_shift
                coord_[:, :, :, 1] += vy * ry + eps_shift
                coord_.clamp_(-1 + 1e-6, 1 - 1e-6)
                
                feat_     = F.grid_sample(feat,   coord_.flip(-1), mode='nearest', align_corners=False)
                old_coord = F.grid_sample(pos_lr, coord_.flip(-1), mode='nearest', align_corners=False)
                rel_coord = coord.permute(0, 3, 1, 2) - old_coord
                rel_coord[:, 0, :, :] *= feat.shape[-2]
                rel_coord[:, 1, :, :] *= feat.shape[-1]
                
                area = torch.abs(rel_coord[:, 0, :, :] * rel_coord[:, 1, :, :])
                areas.append(area + 1e-9)
                
                rel_coords.append(rel_coord)
                feat_s.append(feat_)
            
        rel_cell        = cell.clone()
        rel_cell[:, 0] *= feat.shape[-2]
        rel_cell[:, 1] *= feat.shape[-1]
        
        tot_area = torch.stack(areas).sum(dim=0)
        t = areas[0]; areas[0] = areas[3]; areas[3] = t
        t = areas[1]; areas[1] = areas[2]; areas[2] = t
        
        for index, area in enumerate(areas):
            feat_s[index] = feat_s[index] * (area / tot_area).unsqueeze(1)
        
        grid = torch.cat([
            *rel_coords,
            *feat_s,
            rel_cell.unsqueeze(-1).unsqueeze(-1).repeat(1, 1, coord.shape[1], coord.shape[2])
        ], dim=1)
        x = self.conv00(grid)
        x = self.conv0(x, 0)
        x = self.conv1(x, 1)
        
        feat        = x
        illu_res    = self.fc2(F.gelu(self.fc1(feat)))
        illu        = illu_res + image
        image_fixed = image / (illu + 1e-8)
        
        return illu_res, illu, image_fixed
    
    def forward(self, image: torch.Tensor, depth: torch.Tensor = None) -> torch.Tensor:
        # Prepare input
        if depth is None:
            depth = core.rgb_to_grayscale(image)
        edge = self.dba(depth)
        #
        h     = int(image.shape[-2] * int(self.scale))
        w     = int(image.shape[-1] * int(self.scale))
        scale = h / image.shape[-2]
        coord = make_coords((h, w), flatten=False).to(image.device)
        coord = coord.unsqueeze(0)
        cell         = torch.ones(1, 2).to(image.device)
        cell[:, 0]  *= 2 / h
        cell[:, 1]  *= 2 / w
        cell_factor  = max(scale / 4, 1)
        cell         = cell * cell_factor
        # Generate features
        image_hsv = core.rgb_to_hsv(image)
        image_v   = core.rgb_to_v(image)
        feat      = self.encoder(image_v)
        illu_res, illu, image_fixed = self.query_rgb(image_v, feat, coord, cell)
        image_hsv_fixed = self.replace_v_component(image_hsv, image_fixed)
        enhanced = core.hsv_to_rgb(image_hsv_fixed)
        enhanced = enhanced / torch.max(enhanced)
        
        # Return
        return {
            "image"   : image,
            "depth"   : depth,
            "edge"    : edge,
            "illu_res": illu_res,
            "illu"    : illu,
            "enhanced": enhanced,
        }

# endregion


# region Model

@MODELS.register(name="lno", arch="lno")
class LNO(base.ImageEnhancementModel):
    
    model_dir: core.Path    = current_dir
    arch     : str          = "lno"
    tasks    : list[Task]   = [Task.LLIE]
    schemes  : list[Scheme] = [Scheme.ZERO_REFERENCE, Scheme.INSTANCE]
    zoo      : dict         = {}
    
    def __init__(
        self,
        name        : str   = "lno",
        width       : int   = 256,
        blocks      : int   = 16,
        n_resblocks : int   = 16,
        n_feats     : int   = 64,
        res_scale   : float = 1,
        scale       : int   = 1,
        gf_radius   : int   = 3,
        color_space : Literal["rgb", "rgb_d", "hsv_v", "hsv_v_d"] = "rgb",
        use_denoise : bool  = False,
        use_pse     : bool  = False,
        number_refs : int   = 2,
        weight_enh  : float = 5,
        loss_hsv    : bool  = True,
        exp_mean    : float = 0.6,
        weight_spa  : float = 1,
        weight_exp  : float = 10,
        weight_color: float = 5,
        weight_tv   : float = 1600,
        weights     : Any   = None,
        *args, **kwargs
    ):
        super().__init__(name=name, weights=weights, *args, **kwargs)
        self.color_space = color_space
        self.use_pse     = use_pse
        self.number_refs = number_refs
        self.weight_enh  = weight_enh
        
        self.model = NO_HSV(
            width       = width,
            blocks      = blocks,
            n_resblocks = n_resblocks,
            n_feats     = n_feats,
            res_scale   = res_scale,
            scale       = scale,
            gf_radius   = gf_radius,
            use_denoise = use_denoise,
        )
        
        self.pseudo_gt_generator = utils.PseudoGTGenerator(
            number_refs   = self.number_refs,
            gamma_upper   = -2,
            gamma_lower   =  3,
            exposed_level =  0.5,
            pool_size     =  25,
        )
        self.saved_input     = None
        self.saved_pseudo_gt = None
        
        # Loss
        self.loss = Loss(
            exp_mean     = exp_mean,
            weight_spa   = weight_spa,
            weight_exp   = weight_exp,
            weight_color = weight_color,
            weight_tv    = weight_tv,
        )
        self.loss_recon = nn.MSELoss()
        
        # Load weights
        if self.weights:
            self.load_weights()
        else:
            self.apply(self.init_weights)
        self.initial_state_dict = self.state_dict()
    
    def init_weights(self, m: nn.Module):
        pass
    
    def compute_efficiency_score(
        self,
        image_size: _size_2_t = 512,
        channels  : int       = 3,
        runs      : int       = 1000,
        verbose   : bool      = False,
    ) -> tuple[float, float, float]:
        """Compute the efficiency score of the model, including FLOPs, number
        of parameters, and runtime.
        """
        # Define input tensor
        h, w      = core.get_image_size(image_size)
        datapoint = {
            "image": torch.rand(1, channels, h, w).to(self.device),
            "depth": torch.rand(1,        1, h, w).to(self.device)
        }
        
        # Get FLOPs and Params
        flops, params = core.custom_profile(self, inputs=datapoint, verbose=verbose)
        # flops         = FlopCountAnalysis(self, datapoint).total() if flops == 0 else flops
        params        = self.params                if hasattr(self, "params") and params == 0 else params
        params        = parameter_count(self)      if hasattr(self, "params")  else params
        params        = sum(list(params.values())) if isinstance(params, dict) else params
        
        # Get time
        timer = core.Timer()
        for i in range(runs):
            timer.tick()
            _ = self.forward(datapoint)
            timer.tock()
        avg_time = timer.avg_time
        
        # Print
        if verbose:
            console.log(f"FLOPs (G) : {flops:.4f}")
            console.log(f"Params (M): {params:.4f}")
            console.log(f"Time (s)  : {avg_time:.17f}")
        
        return flops, params, avg_time
    
    def forward_loss(self, datapoint: dict, *args, **kwargs) -> dict:
        # Forward
        self.assert_datapoint(datapoint)
        if self.use_pse:
            # Saving n-th input and n-th pseudo gt
            nth_input     = datapoint
            nth_output    = self.forward(datapoint=datapoint, *args, **kwargs)
            nth_image     = nth_output["image"]
            nth_enhanced  = nth_output["enhanced"].clone().detach()
            nth_pseudo_gt = self.pseudo_gt_generator(nth_image, nth_enhanced)
            if self.saved_input is not None:
                # Getting (n - 1)th input and (n - 1)-th pseudo gt -> calculate loss -> update model weight (handled automatically by pytorch lightning)
                outputs         = self.forward(datapoint=self.saved_input, *args, **kwargs)
                image           = outputs["image"]
                illu            = outputs["illu"]
                enhanced        = outputs["enhanced"]
                pseudo_gt       = self.saved_pseudo_gt
                loss_recon      = self.loss_recon(enhanced, pseudo_gt)
                loss_enh        = self.loss(image, illu, enhanced)
                loss            = loss_recon + loss_enh * self.weight_enh
                outputs["loss"] = loss
            else:  # Skip updating model's weight at the first batch
                outputs = {"loss": None}
            # Saving n-th input and n-th pseudo gt
            self.saved_input     = nth_input
            self.saved_pseudo_gt = nth_pseudo_gt
        else:
            outputs         = self.forward(datapoint=datapoint, *args, **kwargs)
            image           = outputs["image"]
            illu            = outputs["illu"]
            enhanced        = outputs["enhanced"]
            outputs["loss"] = self.loss(image, illu, enhanced)
        return outputs
        
    def forward(self, datapoint: dict, *args, **kwargs) -> dict:
        # Prepare input
        self.assert_datapoint(datapoint)
        image   = datapoint.get("image")
        depth   = datapoint.get("depth")
        outputs = self.model(image, depth)
        # Return
        return outputs
       
    def infer(
        self,
        datapoint    : dict,
        epochs       : int   = 100,
        lr           : float = 1e-5,
        weight_decay : float = 3e-4,
        reset_weights: bool  = True,
        *args, **kwargs
    ) -> dict:
        # Initialize training components
        self.train()
        if reset_weights:
            self.load_state_dict(self.initial_state_dict)
        if isinstance(self.optims, dict):
            optimizer = self.optims.get("optimizer", None)
        else:
            optimizer = nn.Adam(
                self.parameters(),
                lr           = lr,
                betas        = (0.9, 0.999),
                weight_decay = weight_decay
            )
        
        # Pre-processing
        self.saved_input     = None
        self.saved_pseudo_gt = None
        self.assert_datapoint(datapoint)
        for k, v in datapoint.items():
            if isinstance(v, torch.Tensor):
                datapoint[k] = v.to(self.device)
        
        # Training
        for _ in range(epochs):
            outputs = self.forward_loss(datapoint=datapoint)
            optimizer.zero_grad()
            loss    = outputs["loss"]
            if loss is not None:
                loss.backward(retain_graph=True)
                optimizer.step()
            # if self.verbose:
            #    console.log(f"Loss: {loss.item()}")
            
        # Forward
        self.eval()
        timer = core.Timer()
        timer.tick()
        outputs = self.forward(datapoint=datapoint)
        timer.tock()
        self.assert_outputs(outputs)
        
        # Return
        outputs["time"] = timer.avg_time
        return outputs

# endregion
