#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Light Effect Suppression.

This package implements light effect suppression algorithms and models.
"""

from __future__ import annotations
